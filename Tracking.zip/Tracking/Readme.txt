This is the folder structure necessary for performing the tracking.
